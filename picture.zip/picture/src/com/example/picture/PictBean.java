package com.example.picture;

import java.util.List;

public class PictBean {
	public String code;
	public String success;
	public List<javabean> newslist; 
public class javabean{
	public String ctime;
	public String description;
	public String picUrl;
	public String title;
	public String url;
	
	
}

}
