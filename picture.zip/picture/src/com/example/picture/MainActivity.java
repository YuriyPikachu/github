package com.example.picture;

import java.util.ArrayList;
import java.util.List;

import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.Response.ErrorListener;
import com.android.volley.Response.Listener;


import com.example.picture.PictBean.javabean;
import com.example.picture.VolleyRequest.MyStringRequest;
import com.google.gson.Gson;
import com.nostra13.universalimageloader.core.ImageLoader;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

public class MainActivity extends Activity {
	private ListView listview;
	private String url ="http://apis.baidu.com/txapi/mvtp/meinv?num=20";
private List<javabean> list=new ArrayList<javabean>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listview=(ListView) findViewById(R.id.listview);
        initdata();
       
    }
	private void initdata() {
		// TODO Auto-generated method stub
		
		MyStringRequest myStringRequest=new MyStringRequest(Request.Method.GET, url, new Listener<String>() {

			@Override
			public void onResponse(String response) {
			
				Gson gson = new Gson();
				PictBean pictbean = gson.fromJson(response, PictBean.class);
				//System.out.println(pictbean.newslist.get(0).title);
				list.addAll(pictbean.newslist);
				 listview.setAdapter(new Myadapter(list));
				System.out.println(list);
				//System.out.println(response);
			}
		}, new ErrorListener() {

			@Override
			public void onErrorResponse(VolleyError error) {
				// TODO Auto-generated method stub
				
			}
		});
		myStringRequest.headers.put("apikey",
				"b175540c4e40810cd78cc3e9fa4d936c");
		MyApplication.getHttpQueues().add(myStringRequest);
		
	}
	class Myadapter extends BaseAdapter{
		List<javabean> list;
		public Myadapter(List<javabean> list) {
			// TODO Auto-generated constructor stub
			this.list=list;
		}

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return list.size();
		}

		@Override
		public Object getItem(int position) {
			// TODO Auto-generated method stub
			return list.get(position);
		}

		@Override
		public long getItemId(int position) {
			// TODO Auto-generated method stub
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			// TODO Auto-generated method stub
			View view;
			if(convertView==null){
				view=View.inflate(getApplicationContext(), R.layout.item_pic, null);
			}else{
				view=convertView;
			}
			TextView tv=(TextView) view.findViewById(R.id.tv);
			ImageView iv=(ImageView) view.findViewById(R.id.iv);
			tv.setText(list.get(position).title);
			ImageLoader.getInstance().displayImage(list.get(position).picUrl, iv,ImageLoaderOptions.pager_options);
			return view;
		}
		
	}
    


   
    
}
