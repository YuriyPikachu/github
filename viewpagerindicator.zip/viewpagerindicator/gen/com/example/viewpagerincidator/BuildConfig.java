/** Automatically generated file. DO NOT MODIFY */
package com.example.viewpagerincidator;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}