package com.example.viewpagerincidator;

import java.util.ArrayList;
import java.util.List;

import com.example.xiangmuer.view.pagerindicator.TabPageIndicator;

import android.os.Bundle;
import android.app.Activity;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

public class MainActivity extends Activity {
	private MyPagerAdapter mypageradapter;
	private TabPageIndicator indicator;
	private ViewPager viewpager;
	private String[] text={"����","����","����"};
	private int[] arr={R.drawable.a,R.drawable.b,R.drawable.d};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initview();
        initdata();
        
    }

	private void initview() {
		viewpager=(ViewPager) findViewById(R.id.viewpager);

		indicator=(TabPageIndicator) findViewById(R.id.indicator);
		
		
	}
	private void initdata() {
		// TODO Auto-generated method stub
		
		mypageradapter=new MyPagerAdapter();
		viewpager.setAdapter(mypageradapter);
		//��indicator��viewpager�M�н���
		indicator.setViewPager(viewpager);
		
	}
	
	
	class MyPagerAdapter extends PagerAdapter{

		@Override
		public int getCount() {
			// TODO Auto-generated method stub
			return arr.length;
		}

		@Override
		public boolean isViewFromObject(View arg0, Object arg1) {
			// TODO Auto-generated method stub
			return arg0==arg1;
		}

		@Override
		public void destroyItem(ViewGroup container, int position, Object object) {
		
			container.removeView((View)object);
		}


		@Override
		public Object instantiateItem(ViewGroup container, int position) {
			View view=View.inflate(getApplicationContext(), R.layout.item, null);
			ImageView iv= (ImageView) view.findViewById(R.id.iv);
			iv.setImageResource(arr[position]);
			container.addView(view);// һ�������٣���view���뵽viewPager��
			return view;
		}

		//��ָ��ȥ���ñ�������
		public CharSequence getPageTitle(int position) {
			//�����������ô�Զ����ɵ�
			return text[position];
		}
		
		
	}


     
    
}
