/** Automatically generated file. DO NOT MODIFY */
package com.wwj.custom.dialog;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}