package com.example.demo2;

import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;

public class MainActivity extends Activity {
	private RTButton rtbtn;
	private RTLayout mylayout;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		rtbtn=(RTButton) findViewById(R.id.rtbtn);
		mylayout=(RTLayout) findViewById(R.id.mylayout);
		
		//�԰�ť����ontouch��������
		rtbtn.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					System.out.println("RTButton---ontouch----DOWN");
					break;
				case MotionEvent.ACTION_MOVE:
					System.out.println("RTButton---ontouch----MOVE");
					break;
				case MotionEvent.ACTION_UP:
					System.out.println("RTButton---ontouch----UP");
					break;

				default:
					break;
				}
				return false;
			}
		});
		
		
		//�԰�ť����onclick����
		rtbtn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				System.out.println("RTButton clicked");
				
			}
		});
		//��RTLayout����ontouch��������
		mylayout.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				switch (event.getAction()) {
				case MotionEvent.ACTION_DOWN:
					System.out.println("RTLayout---onTouch---DOWN");
					break;
				case MotionEvent.ACTION_MOVE:
					System.out.println("RTLayout---onTouch---MOVE");
					break;
				case MotionEvent.ACTION_UP:
					System.out.println("RTLayout---onTouch---UP");
					break;

				default:
					break;
				}

				return false;
			}
		});
		//RTLayout����onclick����
		mylayout.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				System.out.println("RTLayout clicked!");
				
			}
		});
		
		
		
		
		
		
		
		
		
		
		
		
		

	}
	//Activity��dispatchTouchEvent�ķ���
     @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
    	// TODO Auto-generated method stub
    	 switch (ev.getAction()) {
 		case MotionEvent.ACTION_DOWN:
 			System.out.println("Activity----dispatchTouchEvent----DOWN");			
 			break;
 		case MotionEvent.ACTION_MOVE:
 			System.out.println("Activity----dispatchTouchEvent----MOVE");			
 			break;
 		case MotionEvent.ACTION_UP:
 			System.out.println("Activity----dispatchTouchEvent----UP");			
 			break;
 		default:
 			break;
 		}
    	return super.dispatchTouchEvent(ev);
    }
      @Override
    public boolean onTouchEvent(MotionEvent event) {
    	// TODO Auto-generated method stub
    	  switch (event.getAction()) {
  		case MotionEvent.ACTION_DOWN:
  			System.out.println("Activity----ontouchevent----DOWN");
  			break;
  		case MotionEvent.ACTION_MOVE:
  			System.out.println("Activity----ontouchevent----MOVE");
  			break;
  		case MotionEvent.ACTION_UP:
  			System.out.println("Activity----ontouchevent----UP");
  			break;

  		default:
  			break;
  		}
    	return super.onTouchEvent(event);
    }
      
      


}
