package com.example.demo2;

import android.content.Context;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.widget.LinearLayout;

public class RTLayout extends LinearLayout{

	public RTLayout(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}
	@Override
	public boolean dispatchTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		switch (ev.getAction()) {
		case MotionEvent.ACTION_DOWN:
			System.out.println("RTLayout---dispatchTouchEvent---DOWN");
			break;
		case MotionEvent.ACTION_MOVE:
			System.out.println("RTLayout---dispatchTouchEvent---MOVE");
			break;
		case MotionEvent.ACTION_UP:
			System.out.println("RTLayout---dispatchTouchEvent---UP");
			break;

		default:
			break;
		}
		return super.dispatchTouchEvent(ev);
	}
	@Override
	public boolean onInterceptTouchEvent(MotionEvent ev) {
		// TODO Auto-generated method stub
		switch (ev.getAction()) {
		case MotionEvent.ACTION_DOWN:
			System.out.println("RTLayout---onInterceptTouchEvent---DOWN");
			break;
		case MotionEvent.ACTION_MOVE:
			System.out.println("RTLayout---onInterceptTouchEvent---MOVE");
			break;
		case MotionEvent.ACTION_UP:
			System.out.println("RTLayout---onInterceptTouchEvent---UP");
			break;

		default:
			break;
		}
		
		return super.onInterceptTouchEvent(ev);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		// TODO Auto-generated method stub
		switch (event.getAction()) {
		case MotionEvent.ACTION_DOWN:
			System.out.println("RTLayout---onTouchEvent---DOWN");
			break;
		case MotionEvent.ACTION_MOVE:
			System.out.println("RTLayout---onTouchEvent---MOVE");
			break;
		case MotionEvent.ACTION_UP:
			System.out.println("RTLayout---onTouchEvent---UP");
			break;


		default:
			break;
		}
		return super.onTouchEvent(event);
	}

}
