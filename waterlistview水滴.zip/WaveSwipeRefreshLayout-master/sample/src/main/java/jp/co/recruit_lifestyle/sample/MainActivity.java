package jp.co.recruit_lifestyle.sample;

import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import jp.co.recruit_lifestyle.android.widget.WaveSwipeRefreshLayout;

public class MainActivity extends AppCompatActivity implements WaveSwipeRefreshLayout.OnRefreshListener {
  private Myadapter myadapter;
  private String str;
  private ListView mListview;


  private WaveSwipeRefreshLayout mWaveSwipeRefreshLayout;
  private LinkedList<String> list=new LinkedList<String>();



  @Override
  protected void onCreate(Bundle savedInstanceState) {
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    getWindow().addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN);
    super.onCreate(savedInstanceState);

    setContentView(R.layout.activity_main);
    initView();
    setSampleData();
  }

  private void initView() {
    mWaveSwipeRefreshLayout = (WaveSwipeRefreshLayout) findViewById(R.id.main_swipe);
    mWaveSwipeRefreshLayout.setColorSchemeColors(Color.WHITE, Color.WHITE);
    mWaveSwipeRefreshLayout.setOnRefreshListener(this);
    mWaveSwipeRefreshLayout.setWaveColor(Color.DKGRAY);
    //mWaveSwipeRefreshLayout.setMaxDropHeight(1300);

    mListview = (ListView) findViewById(R.id.main_list);
  }

  private void setSampleData() {

    for (int i = 0; i < 60; i++) {
      list.add("你好" );
    }
   myadapter=new Myadapter(list);
    mListview.setAdapter(myadapter);
  }
  class Myadapter extends BaseAdapter{
     List<String> list=new ArrayList<String>();
       public Myadapter (List<String> list){
      this.list=list;
    }

    @Override
    public int getCount() {
      return list.size();
    }

    @Override
    public Object getItem(int i) {
      return list.get(i);
    }

    @Override
    public long getItemId(int i) {
      return i;
    }

    @Override
    public View getView(int i, View converView, ViewGroup viewGroup) {
    View view;
      if (converView==null){
        view=View.inflate(MainActivity.this,R.layout.item,null);
      }else {
        view=converView;
      }
      TextView tvitem= (TextView) view.findViewById(R.id.tvitem);
      tvitem.setText(list.get(i));
      return view;
    }
  }

  private void refresh(){
    new Handler().postDelayed(new Runnable() {
      @Override
      public void run() {
        // 更新が終了したらインジケータ非表示
        new Task().execute();

        mWaveSwipeRefreshLayout.setRefreshing(false);
      }
    }, 3000);
  }

  class Task extends AsyncTask<Void, Void,String>{

    @Override
    protected String doInBackground(Void... voids) {

      try {
        Thread.sleep(500);
        for (int a=0;a<10;a++){
 str="我是被添加的";

        }
      } catch (InterruptedException e) {
        e.printStackTrace();
      }
      return str;

    }

    @Override
    protected void onPostExecute(String stringlist) {
 list.addFirst(stringlist);
      myadapter.notifyDataSetChanged();



      mWaveSwipeRefreshLayout.setRefreshing(false);

      super.onPostExecute(stringlist);
    }
  }

  @Override
  protected void onResume() {
    mWaveSwipeRefreshLayout.setRefreshing(true);
    refresh();
    super.onResume();
  }

  @Override
  public void onRefresh() {
    refresh();
  }

  @Override
  public boolean onCreateOptionsMenu(Menu menu) {
    // Inflate the menu; this adds items to the action bar if it is present.
    getMenuInflater().inflate(R.menu.menu_main, menu);
    return true;
  }

  @Override
  public boolean onOptionsItemSelected(MenuItem item) {
    // Handle action bar item clicks here. The action bar will
    // automatically handle clicks on the Home/Up button, so long
    // as you specify a parent activity in AndroidManifest.xml.
    int id = item.getItemId();

    //noinspection SimplifiableIfStatement
    if (id == R.id.action_settings) {
      mWaveSwipeRefreshLayout.setRefreshing(true);
      refresh();
      return true;
    }

    return super.onOptionsItemSelected(item);
  }
}
