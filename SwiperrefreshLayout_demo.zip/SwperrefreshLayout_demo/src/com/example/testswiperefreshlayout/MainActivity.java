package com.example.testswiperefreshlayout;

import java.util.ArrayList;

import android.R.array;
import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v4.widget.SwipeRefreshLayout.OnRefreshListener;
import android.util.Log;
import android.widget.ListView;

public class MainActivity extends Activity {

	private SwipeRefreshLayout swipeRefreshLayout;
	private ListView listView;
	private ListViewAdapter adapter;
	private ArrayList<String> arrayList;
	private int f = 0;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		swipeRefreshLayout = (SwipeRefreshLayout) findViewById(R.id.swipe_container);
		Log.d("swipeRefreshLayout----->", swipeRefreshLayout.toString());
		
		//給刷新頭設置顔色，最多可以設置4個
		swipeRefreshLayout.setColorScheme(android.R.color.white,
				android.R.color.holo_green_light,
				android.R.color.holo_orange_light,
				android.R.color.holo_red_light);
//對刷新的操作
		swipeRefreshLayout.setOnRefreshListener(new OnRefreshListener() {

			@Override
			public void onRefresh() {
				// TODO Auto-generated method stub
				new Handler().postDelayed(new Runnable() {
					public void run() {
						//不讓刷新頭顯示出來
						swipeRefreshLayout.setRefreshing(false);
						//刷新時添加的數據，其中0代表在頭部添加，如果不寫上0，就會添加在尾部
						arrayList.add(0,"---->" + ++f);
						adapter.notifyDataSetChanged();
					}
				}, 3000);
			}
		});
		listView = (ListView) findViewById(R.id.listview);
		initData();
		adapter = new ListViewAdapter(this, arrayList);
		listView.setAdapter(adapter);
	}
//給arraylist添加的數據
	private void initData() {

		arrayList = new ArrayList<String>();
		for (int i = 0; i < 20; i++) {
			arrayList.add("---->" + i);
		}
	}
}
